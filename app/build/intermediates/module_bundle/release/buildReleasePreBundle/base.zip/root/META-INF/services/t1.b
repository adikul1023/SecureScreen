t1.b
